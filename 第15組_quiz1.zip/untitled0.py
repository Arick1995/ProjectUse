import os
import numpy as np
from PIL import Image


'''
overlay_img = overlay_img.convert('RGBA')
data = np.array(overlay_img)
r1,g1,b1 = 255,255,255;
rw,gw,bw,aw=255,255,255,255
'''

def load_im(filename):
    return Image.open(filename)

def resize_im(image):
    return image.resize((800,533),Image.ANTIALIAS)

def im_shift(image,multiply):
    shift_heigth = np.roll(image, 3*multiply, axis=0)
    shift_width = np.roll(image, 3*multiply,axis =1)
    return shift_width

def image_add(image1,image2):
    img1 = Image.fromarray(image1, mode='RGB')
    img2 = Image.fromarray(image2, mode='RGB')
    return Image.blend(img1, img2, 0.5)

im = [load_im('C:/Users/tkustaff/Desktop/egg_roll_square.jpg'),load_im('C:/Users/tkustaff/Desktop/rocket.jpg')]
im[0] = resize_im(im[0])
im[1] = im[1].resize(( int(im[1].width *105 / im[1].height), 105))


# im[1] = im[1].resize((,105))
shifted_im =[]

for num in range(1,51):
    tmp = im[0].copy()
    tmp.paste(im[1],(num*30, 70, num*30 + im[1].width, 70 + im[1].height))
    shifted_im.append(tmp.copy())

shifted_im[0].save('result.gif',save_all = True,append_images=shifted_im[1:],duration=500,loop=0,optimize=True)